export const viewInSeal = async (redirectUrl) => {
    window.open(redirectUrl, "_blank");
  };